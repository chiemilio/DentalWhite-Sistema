import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  generateToken,
  verifyToken,
  getStoredToken,
  saveToken,
  removeToken,
  getStoredTokenPayload,
  type JWTPayload,
} from '../utils/jwt';
import { toast } from 'sonner';

export type UserRole = 'patient' | 'receptionist' | 'doctor' | 'admin';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  phone?: string;
  age?: number;
  sex?: string;
  address?: string;
  colony?: string;
  delegation?: string;
  tutor?: string;
  occupation?: string;
  patientType?: string;
  workCenter?: string;
  specialty?: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users database
const mockUsers: (User & { password: string })[] = [
  {
    id: '1',
    email: 'admin@dentalwhite.com',
    password: 'admin123',
    role: 'admin',
    name: 'Administrador Principal',
  },
  {
    id: '2',
    email: 'recepcion@dentalwhite.com',
    password: 'recep123',
    role: 'receptionist',
    name: 'María González',
    workCenter: 'Pénjamo',
  },
  {
    id: '3',
    email: 'doctor@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Carlos Méndez',
    specialty: 'Odontología General',
    workCenter: 'Pénjamo',
  },
  {
    id: '4',
    email: 'paciente@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'Juan Pérez',
    phone: '5512345678',
    age: 32,
    sex: 'Masculino',
    address: 'Calle Principal 123',
    colony: 'Centro',
    delegation: 'Cuauhtémoc',
    workCenter: 'Pénjamo',
  },
  // Nuevos usuarios
  {
    id: '5',
    email: 'admin2@dentalwhite.com',
    password: 'admin123',
    role: 'admin',
    name: 'Dr. Faustino Vázquez Rodríguez',
  },
  {
    id: '6',
    email: 'recepcion.valle@dentalwhite.com',
    password: 'recep123',
    role: 'receptionist',
    name: 'Ana Martínez',
    workCenter: 'Valle de Santiago',
  },
  {
    id: '7',
    email: 'recepcion.abasolo@dentalwhite.com',
    password: 'recep123',
    role: 'receptionist',
    name: 'Laura Sánchez',
    workCenter: 'Abasolo',
  },
  {
    id: '8',
    email: 'doctor.ortodoncia@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dra. Patricia Hernández',
    specialty: 'Ortodoncia',
    workCenter: 'Pénjamo',
  },
  {
    id: '9',
    email: 'doctor.cirugia@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Roberto Martínez',
    specialty: 'Cirugía Maxilofacial',
    workCenter: 'Valle de Santiago',
  },
  {
    id: '10',
    email: 'doctor.endodoncia@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Luis Ramírez',
    specialty: 'Endodoncia',
    workCenter: 'Pénjamo',
  },
  {
    id: '11',
    email: 'doctor.odontopediatria@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dra. Carmen López',
    specialty: 'Odontopediatría',
    workCenter: 'Abasolo',
  },
  {
    id: '12',
    email: 'doctor.implantes@dentalwhite.com',
    password: 'doctor123',
    role: 'doctor',
    name: 'Dr. Miguel Flores',
    specialty: 'Implantología',
    workCenter: 'Valle de Santiago',
  },
  {
    id: '13',
    email: 'maria.garcia@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'María García',
    phone: '4771234567',
    age: 28,
    sex: 'Femenino',
    address: 'Avenida Juárez 456',
    colony: 'La Concepción',
    delegation: 'Valle de Santiago',
    workCenter: 'Valle de Santiago',
  },
  {
    id: '14',
    email: 'pedro.lopez@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'Pedro López',
    phone: '4691234567',
    age: 45,
    sex: 'Masculino',
    address: 'Calle Hidalgo 789',
    colony: 'Centro',
    delegation: 'Abasolo',
    workCenter: 'Abasolo',
  },
  {
    id: '15',
    email: 'sofia.martinez@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'Sofía Martínez',
    phone: '4691234568',
    age: 12,
    sex: 'Femenino',
    address: 'Calle Allende 321',
    colony: 'El Rosario',
    delegation: 'Abasolo',
    tutor: 'Ana Martínez (Madre)',
    workCenter: 'Abasolo',
  },
  {
    id: '16',
    email: 'carlos.rodriguez@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'Carlos Rodríguez',
    phone: '4691234569',
    age: 38,
    sex: 'Masculino',
    address: 'Calle Morelos 654',
    colony: 'San José',
    delegation: 'Pénjamo',
    occupation: 'Contador',
    workCenter: 'Pénjamo',
  },
  {
    id: '17',
    email: 'lucia.fernandez@example.com',
    password: 'paciente123',
    role: 'patient',
    name: 'Lucía Fernández',
    phone: '4771234568',
    age: 52,
    sex: 'Femenino',
    address: 'Avenida Independencia 987',
    colony: 'Lomas',
    delegation: 'Valle de Santiago',
    occupation: 'Maestra',
    workCenter: 'Valle de Santiago',
  },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [users, setUsers] = useState(mockUsers);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Restore session from stored token on mount
  useEffect(() => {
    const restoreSession = async () => {
      try {
        const storedToken = getStoredToken();
        if (storedToken) {
          const payload = await getStoredTokenPayload();
          if (payload) {
            const foundUser = users.find((u) => u.id === payload.userId);
            if (foundUser) {
              const { password: _, ...userWithoutPassword } = foundUser;
              setUser(userWithoutPassword);
              setToken(storedToken);
              setIsAuthenticated(true);
            }
          }
        }
      } catch (error) {
        console.error('Error restoring session:', error);
        removeToken();
      } finally {
        setIsLoading(false);
      }
    };

    restoreSession();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const foundUser = users.find(
        (u) => u.email === email && u.password === password
      );
      
      if (foundUser) {
        const { password: _, ...userWithoutPassword } = foundUser;
        
        // Generate JWT token
        const jwtToken = await generateToken({
          userId: userWithoutPassword.id,
          email: userWithoutPassword.email,
          role: userWithoutPassword.role,
          name: userWithoutPassword.name,
          workCenter: userWithoutPassword.workCenter,
          specialty: userWithoutPassword.specialty,
        });

        saveToken(jwtToken);
        setUser(userWithoutPassword);
        setToken(jwtToken);
        setIsAuthenticated(true);
        
        toast.success(`Bienvenido ${userWithoutPassword.name}`);
        return true;
      }
      
      toast.error('Credenciales incorrectas');
      return false;
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Error al iniciar sesión');
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setIsAuthenticated(false);
    removeToken();
    toast.info('Sesión cerrada');
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<boolean> => {
    try {
      // Check if email already exists
      if (users.some((u) => u.email === userData.email)) {
        toast.error('El email ya está registrado');
        return false;
      }

      const newUser = {
        id: (users.length + 1).toString(),
        role: 'patient' as UserRole,
        ...userData,
      };

      setUsers([...users, newUser as any]);
      toast.success('Registro completado exitosamente');
      return true;
    } catch (error) {
      console.error('Register error:', error);
      toast.error('Error al registrar usuario');
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, register, isAuthenticated, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}