import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Users, UserPlus, Edit, Trash2, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Textarea } from '../ui/textarea';
import { toast } from 'sonner';
import {
  employees as initialEmployees,
  patients as initialPatients,
  appointments as initialAppointments,
  services as initialServices,
  workCenters,
  type Employee,
  type Patient,
  type Service,
} from '../../data/mockData';
import { ReportsSection } from '../ReportsSection';
import { BlockSchedule } from '../BlockSchedule';

export function AdminDashboard() {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [patients, setPatients] = useState<Patient[]>(initialPatients);
  const [appointments, setAppointments] = useState(initialAppointments);
  const [services, setServices] = useState<Service[]>(initialServices);
  const [isCreateEmployeeDialogOpen, setIsCreateEmployeeDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [filterRole, setFilterRole] = useState<string>('all');

  // Patient states
  const [isCreatePatientDialogOpen, setIsCreatePatientDialogOpen] = useState(false);
  const [isEditPatientDialogOpen, setIsEditPatientDialogOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [newPatient, setNewPatient] = useState<Partial<Patient>>({
    name: '',
    email: '',
    phone: '',
    age: undefined,
    sex: '',
    address: '',
    colony: '',
    delegation: '',
    municipality: '',
    tutor: '',
    occupation: '',
    patientType: 'Regular',
    workCenter: '',
  });

  const [newEmployee, setNewEmployee] = useState<Partial<Employee>>({
    name: '',
    email: '',
    role: 'receptionist',
    phone: '',
    specialty: '',
    workCenter: '',
    status: 'active',
  });

  const handleCreateEmployee = () => {
    if (!newEmployee.name || !newEmployee.email || !newEmployee.phone) {
      toast.error('Por favor completa todos los campos obligatorios');
      return;
    }

    const employee: Employee = {
      id: (employees.length + 1).toString(),
      hireDate: new Date().toISOString().split('T')[0],
      ...newEmployee,
    } as Employee;

    setEmployees([...employees, employee]);
    setNewEmployee({
      name: '',
      email: '',
      role: 'receptionist',
      phone: '',
      specialty: '',
      workCenter: '',
      status: 'active',
    });
    setIsCreateEmployeeDialogOpen(false);
    toast.success('Empleado creado exitosamente');
  };

  const handleEditEmployee = () => {
    if (!editingEmployee) return;

    setEmployees(
      employees.map((emp) => (emp.id === editingEmployee.id ? editingEmployee : emp))
    );
    setIsEditDialogOpen(false);
    setEditingEmployee(null);
    toast.success('Empleado actualizado exitosamente');
  };

  const handleDeleteEmployee = (id: string) => {
    if (id === '1') {
      toast.error('No puedes eliminar al administrador principal');
      return;
    }
    setEmployees(employees.filter((emp) => emp.id !== id));
    toast.success('Empleado eliminado');
  };

  const handleToggleStatus = (id: string) => {
    setEmployees(
      employees.map((emp) =>
        emp.id === id
          ? { ...emp, status: emp.status === 'active' ? 'inactive' : 'active' }
          : emp
      )
    );
    toast.success('Estado actualizado');
  };

  const filteredEmployees = employees.filter(
    (emp) => filterRole === 'all' || emp.role === filterRole
  );

  const handleCancelAppointment = (id: string) => {
    setAppointments(
      appointments.map((apt) =>
        apt.id === id ? { ...apt, status: 'cancelled' as const } : apt
      )
    );
    toast.success('Cita cancelada');
  };

  const handleCreatePatient = () => {
    if (!newPatient.name || !newPatient.email || !newPatient.phone) {
      toast.error('Por favor completa todos los campos obligatorios');
      return;
    }

    const patient: Patient = {
      id: (patients.length + 1).toString(),
      registrationDate: new Date().toISOString().split('T')[0],
      ...newPatient,
    } as Patient;

    setPatients([...patients, patient]);
    setNewPatient({
      name: '',
      email: '',
      phone: '',
      age: undefined,
      sex: '',
      address: '',
      colony: '',
      delegation: '',
      municipality: '',
      tutor: '',
      occupation: '',
      patientType: 'Regular',
      workCenter: '',
    });
    setIsCreatePatientDialogOpen(false);
    toast.success('Paciente creado exitosamente');
  };

  const handleEditPatient = () => {
    if (!editingPatient) return;

    setPatients(
      patients.map((pat) => (pat.id === editingPatient.id ? editingPatient : pat))
    );
    setIsEditPatientDialogOpen(false);
    setEditingPatient(null);
    toast.success('Paciente actualizado exitosamente');
  };

  const handleDeletePatient = (id: string) => {
    setPatients(patients.filter((pat) => pat.id !== id));
    toast.success('Paciente eliminado');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl text-sky-600">Panel Administrativo</h2>
        <p className="text-gray-600">Gestión completa del sistema</p>
      </div>

      {/* Statistics */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="border-sky-200">
          <CardHeader className="pb-2">
            <CardDescription>Empleados Activos</CardDescription>
            <CardTitle className="text-3xl text-sky-600">{employees.filter((e) => e.status === 'active').length}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="border-sky-200">
          <CardHeader className="pb-2">
            <CardDescription>Pacientes Registrados</CardDescription>
            <CardTitle className="text-3xl text-sky-600">{patients.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="border-sky-200">
          <CardHeader className="pb-2">
            <CardDescription>Citas Activas</CardDescription>
            <CardTitle className="text-3xl text-sky-600">{appointments.filter((a) => a.status !== 'cancelled').length}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="border-sky-200">
          <CardHeader className="pb-2">
            <CardDescription>Citas Completadas</CardDescription>
            <CardTitle className="text-3xl text-sky-600">{appointments.filter((a) => a.status === 'completed').length}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <Tabs defaultValue="employees" className="w-full">
        <TabsList className="grid w-full max-w-2xl grid-cols-4">
          <TabsTrigger value="employees">Empleados</TabsTrigger>
          <TabsTrigger value="patients">Pacientes</TabsTrigger>
          <TabsTrigger value="appointments">Citas</TabsTrigger>
          <TabsTrigger value="reports">Reportes</TabsTrigger>
        </TabsList>

        {/* Employees Tab */}
        <TabsContent value="employees" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Label>Filtrar por rol:</Label>
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="w-48 border-sky-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="admin">Administradores</SelectItem>
                  <SelectItem value="doctor">Médicos</SelectItem>
                  <SelectItem value="receptionist">Recepcionistas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Dialog open={isCreateEmployeeDialogOpen} onOpenChange={setIsCreateEmployeeDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-sky-500 hover:bg-sky-600">
                  <UserPlus className="mr-2" size={20} />
                  Crear Empleado
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-sky-600">Crear Nuevo Empleado</DialogTitle>
                  <DialogDescription>
                    Completa los datos del nuevo empleado
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nombre Completo *</Label>
                      <Input
                        value={newEmployee.name}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, name: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Email *</Label>
                      <Input
                        type="email"
                        value={newEmployee.email}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, email: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Teléfono *</Label>
                      <Input
                        value={newEmployee.phone}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, phone: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Rol *</Label>
                      <Select
                        value={newEmployee.role}
                        onValueChange={(value: any) =>
                          setNewEmployee({ ...newEmployee, role: value })
                        }
                      >
                        <SelectTrigger className="border-sky-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="receptionist">Recepcionista</SelectItem>
                          <SelectItem value="doctor">Médico</SelectItem>
                          <SelectItem value="admin">Administrador</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {newEmployee.role === 'doctor' && (
                      <div className="space-y-2">
                        <Label>Especialidad</Label>
                        <Input
                          value={newEmployee.specialty}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, specialty: e.target.value })
                          }
                          className="border-sky-200"
                        />
                      </div>
                    )}
                    <div className="space-y-2">
                      <Label>Sucursal</Label>
                      <Select
                        value={newEmployee.workCenter}
                        onValueChange={(value: any) =>
                          setNewEmployee({ ...newEmployee, workCenter: value })
                        }
                      >
                        <SelectTrigger className="border-sky-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {workCenters.map((center) => (
                            <SelectItem key={center.id} value={center.name}>
                              {center.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button
                    onClick={handleCreateEmployee}
                    className="w-full bg-sky-500 hover:bg-sky-600"
                  >
                    Crear Empleado
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card className="border-sky-200">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Rol</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Especialidad/Sucursal</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmployees.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell>{employee.name}</TableCell>
                        <TableCell>{employee.email}</TableCell>
                        <TableCell>
                          <div
                            className={`inline-block px-2 py-1 rounded-full text-xs ${
                              employee.role === 'admin'
                                ? 'bg-purple-100 text-purple-700'
                                : employee.role === 'doctor'
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-green-100 text-green-700'
                            }`}
                          >
                            {employee.role === 'admin'
                              ? 'Admin'
                              : employee.role === 'doctor'
                              ? 'Médico'
                              : 'Recepción'}
                          </div>
                        </TableCell>
                        <TableCell>{employee.phone}</TableCell>
                        <TableCell>
                          {employee.role === 'doctor'
                            ? employee.specialty
                            : employee.workCenter}
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleToggleStatus(employee.id)}
                            className={
                              employee.status === 'active'
                                ? 'border-green-300 text-green-600 hover:bg-green-50'
                                : 'border-red-300 text-red-600 hover:bg-red-50'
                            }
                          >
                            {employee.status === 'active' ? 'Activo' : 'Inactivo'}
                          </Button>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingEmployee(employee);
                                setIsEditDialogOpen(true);
                              }}
                              className="border-sky-300 text-sky-600 hover:bg-sky-50"
                            >
                              <Edit size={16} />
                            </Button>
                            {employee.id !== '1' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteEmployee(employee.id)}
                                className="border-red-300 text-red-600 hover:bg-red-50"
                              >
                                <Trash2 size={16} />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Patients Tab */}
        <TabsContent value="patients" className="space-y-4">
          <div className="flex items-center justify-between">
            <CardHeader>
              <CardTitle className="text-sky-600">Pacientes Registrados</CardTitle>
              <CardDescription>Total: {patients.length} pacientes</CardDescription>
            </CardHeader>
            <Dialog open={isCreatePatientDialogOpen} onOpenChange={setIsCreatePatientDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-sky-500 hover:bg-sky-600">
                  <UserPlus className="mr-2" size={20} />
                  Crear Paciente
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-sky-600">Crear Nuevo Paciente</DialogTitle>
                  <DialogDescription>
                    Completa los datos del nuevo paciente
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nombre Completo *</Label>
                      <Input
                        value={newPatient.name}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, name: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Email *</Label>
                      <Input
                        type="email"
                        value={newPatient.email}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, email: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Teléfono *</Label>
                      <Input
                        value={newPatient.phone}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, phone: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Edad</Label>
                      <Input
                        type="number"
                        value={newPatient.age?.toString() || ''}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, age: parseInt(e.target.value) })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Sexo</Label>
                      <Select
                        value={newPatient.sex}
                        onValueChange={(value: any) =>
                          setNewPatient({ ...newPatient, sex: value })
                        }
                      >
                        <SelectTrigger className="border-sky-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Masculino</SelectItem>
                          <SelectItem value="female">Femenino</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Dirección</Label>
                      <Input
                        value={newPatient.address}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, address: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Colonia</Label>
                      <Input
                        value={newPatient.colony}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, colony: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Delegación</Label>
                      <Input
                        value={newPatient.delegation}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, delegation: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Municipio</Label>
                      <Input
                        value={newPatient.municipality}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, municipality: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Tutor</Label>
                      <Input
                        value={newPatient.tutor}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, tutor: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Ocupación</Label>
                      <Input
                        value={newPatient.occupation}
                        onChange={(e) =>
                          setNewPatient({ ...newPatient, occupation: e.target.value })
                        }
                        className="border-sky-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Tipo de Paciente</Label>
                      <Select
                        value={newPatient.patientType}
                        onValueChange={(value: any) =>
                          setNewPatient({ ...newPatient, patientType: value })
                        }
                      >
                        <SelectTrigger className="border-sky-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Regular">Regular</SelectItem>
                          <SelectItem value="VIP">VIP</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Sucursal</Label>
                      <Select
                        value={newPatient.workCenter}
                        onValueChange={(value: any) =>
                          setNewPatient({ ...newPatient, workCenter: value })
                        }
                      >
                        <SelectTrigger className="border-sky-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {workCenters.map((center) => (
                            <SelectItem key={center.id} value={center.name}>
                              {center.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button
                    onClick={handleCreatePatient}
                    className="w-full bg-sky-500 hover:bg-sky-600"
                  >
                    Crear Paciente
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card className="border-sky-200">
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Edad</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Sucursal</TableHead>
                      <TableHead>Fecha Registro</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {patients.map((patient) => (
                      <TableRow key={patient.id}>
                        <TableCell>{patient.name}</TableCell>
                        <TableCell>{patient.email}</TableCell>
                        <TableCell>{patient.phone}</TableCell>
                        <TableCell>{patient.age} años</TableCell>
                        <TableCell>{patient.patientType}</TableCell>
                        <TableCell>{patient.workCenter || 'Sin asignar'}</TableCell>
                        <TableCell>
                          {new Date(patient.registrationDate).toLocaleDateString('es-MX')}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingPatient(patient);
                                setIsEditPatientDialogOpen(true);
                              }}
                              className="border-sky-300 text-sky-600 hover:bg-sky-50"
                            >
                              <Edit size={16} />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeletePatient(patient.id)}
                              className="border-red-300 text-red-600 hover:bg-red-50"
                            >
                              <Trash2 size={16} />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appointments Tab */}
        <TabsContent value="appointments" className="space-y-4">
          <Card className="border-sky-200">
            <CardHeader>
              <CardTitle className="text-sky-600">Gestión de Citas</CardTitle>
              <CardDescription>
                Visualiza y administra todas las citas del sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Hora</TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Servicio</TableHead>
                      <TableHead>Médico</TableHead>
                      <TableHead>Sucursal</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {appointments.map((appointment) => (
                      <TableRow key={appointment.id}>
                        <TableCell>
                          {new Date(appointment.date).toLocaleDateString('es-MX')}
                        </TableCell>
                        <TableCell>{appointment.time}</TableCell>
                        <TableCell>{appointment.patientName}</TableCell>
                        <TableCell>{appointment.serviceName}</TableCell>
                        <TableCell>{appointment.doctorName || 'Sin asignar'}</TableCell>
                        <TableCell>{appointment.workCenterName}</TableCell>
                        <TableCell>
                          <div
                            className={`inline-block px-2 py-1 rounded-full text-xs ${
                              appointment.status === 'confirmed'
                                ? 'bg-green-100 text-green-700'
                                : appointment.status === 'cancelled'
                                ? 'bg-red-100 text-red-700'
                                : appointment.status === 'completed'
                                ? 'bg-gray-100 text-gray-700'
                                : 'bg-yellow-100 text-yellow-700'
                            }`}
                          >
                            {appointment.status === 'confirmed'
                              ? 'Confirmada'
                              : appointment.status === 'cancelled'
                              ? 'Cancelada'
                              : appointment.status === 'completed'
                              ? 'Completada'
                              : 'Programada'}
                          </div>
                        </TableCell>
                        <TableCell>
                          {appointment.status !== 'cancelled' &&
                            appointment.status !== 'completed' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleCancelAppointment(appointment.id)}
                                className="border-red-300 text-red-600 hover:bg-red-50"
                              >
                                Cancelar
                              </Button>
                            )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-4">
          <ReportsSection
            employees={employees}
            patients={patients}
            appointments={appointments}
          />
        </TabsContent>
      </Tabs>

      {/* Edit Employee Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-sky-600">Editar Empleado</DialogTitle>
          </DialogHeader>
          {editingEmployee && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre Completo</Label>
                  <Input
                    value={editingEmployee.name}
                    onChange={(e) =>
                      setEditingEmployee({ ...editingEmployee, name: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={editingEmployee.email}
                    onChange={(e) =>
                      setEditingEmployee({ ...editingEmployee, email: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input
                    value={editingEmployee.phone}
                    onChange={(e) =>
                      setEditingEmployee({ ...editingEmployee, phone: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Rol</Label>
                  <Select
                    value={editingEmployee.role}
                    onValueChange={(value: any) =>
                      setEditingEmployee({ ...editingEmployee, role: value })
                    }
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="receptionist">Recepcionista</SelectItem>
                      <SelectItem value="doctor">Médico</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {editingEmployee.role === 'doctor' && (
                  <div className="space-y-2">
                    <Label>Especialidad</Label>
                    <Input
                      value={editingEmployee.specialty}
                      onChange={(e) =>
                        setEditingEmployee({ ...editingEmployee, specialty: e.target.value })
                      }
                      className="border-sky-200"
                    />
                  </div>
                )}
                <div className="space-y-2">
                  <Label>Sucursal</Label>
                  <Select
                    value={editingEmployee.workCenter}
                    onValueChange={(value: any) =>
                      setEditingEmployee({ ...editingEmployee, workCenter: value })
                    }
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {workCenters.map((center) => (
                        <SelectItem key={center.id} value={center.name}>
                          {center.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleEditEmployee}
                className="w-full bg-sky-500 hover:bg-sky-600"
              >
                Guardar Cambios
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Patient Dialog */}
      <Dialog open={isEditPatientDialogOpen} onOpenChange={setIsEditPatientDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-sky-600">Editar Paciente</DialogTitle>
          </DialogHeader>
          {editingPatient && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre Completo</Label>
                  <Input
                    value={editingPatient.name}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, name: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={editingPatient.email}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, email: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input
                    value={editingPatient.phone}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, phone: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Edad</Label>
                  <Input
                    type="number"
                    value={editingPatient.age?.toString() || ''}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, age: parseInt(e.target.value) })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Sexo</Label>
                  <Select
                    value={editingPatient.sex}
                    onValueChange={(value: any) =>
                      setEditingPatient({ ...editingPatient, sex: value })
                    }
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Masculino</SelectItem>
                      <SelectItem value="female">Femenino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Dirección</Label>
                  <Input
                    value={editingPatient.address}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, address: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Colonia</Label>
                  <Input
                    value={editingPatient.colony}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, colony: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Delegación</Label>
                  <Input
                    value={editingPatient.delegation}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, delegation: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Municipio</Label>
                  <Input
                    value={editingPatient.municipality}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, municipality: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tutor</Label>
                  <Input
                    value={editingPatient.tutor}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, tutor: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ocupación</Label>
                  <Input
                    value={editingPatient.occupation}
                    onChange={(e) =>
                      setEditingPatient({ ...editingPatient, occupation: e.target.value })
                    }
                    className="border-sky-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tipo de Paciente</Label>
                  <Select
                    value={editingPatient.patientType}
                    onValueChange={(value: any) =>
                      setEditingPatient({ ...editingPatient, patientType: value })
                    }
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Regular">Regular</SelectItem>
                      <SelectItem value="VIP">VIP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Sucursal</Label>
                  <Select
                    value={editingPatient.workCenter}
                    onValueChange={(value: any) =>
                      setEditingPatient({ ...editingPatient, workCenter: value })
                    }
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {workCenters.map((center) => (
                        <SelectItem key={center.id} value={center.name}>
                          {center.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleEditPatient}
                className="w-full bg-sky-500 hover:bg-sky-600"
              >
                Guardar Cambios
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}