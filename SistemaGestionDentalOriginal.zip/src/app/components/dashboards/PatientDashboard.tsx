import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Calendar, Clock, MapPin, FileText, Plus, X, AlertCircle, Mail, MessageCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { toast } from 'sonner';
import { services, workCenters, type Appointment } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import { useAvailability } from '../../context/AvailabilityContext';
import { sendAppointmentConfirmations, getConfirmationMessage } from '../../utils/appointmentNotifications';

export function PatientDashboard() {
  const { user } = useAuth();
  const { getAvailableTimeSlots, isDayBlocked, isDaySaturated } = useAvailability();
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: '1',
      patientId: user?.id || '4',
      patientName: user?.name || 'Juan Pérez',
      serviceId: '1',
      serviceName: 'Limpieza Dental',
      workCenterId: '1',
      workCenterName: 'Sucursal Centro',
      date: '2026-02-15',
      time: '10:00',
      status: 'scheduled',
      doctorId: '3',
      doctorName: 'Dr. Carlos Méndez',
    },
  ]);

  const [newAppointment, setNewAppointment] = useState({
    serviceId: '',
    workCenterId: '',
    date: '',
    time: '',
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Obtener el nombre de la sucursal seleccionada
  const getSelectedBranchName = () => {
    const workCenter = workCenters.find((w) => w.id === newAppointment.workCenterId);
    return workCenter?.name || '';
  };

  // Filtrar servicios por sucursal seleccionada
  const getAvailableServices = () => {
    if (!newAppointment.workCenterId) return [];
    const branchName = getSelectedBranchName();
    return services.filter((s) => s.branch === branchName);
  };

  // Obtener horarios disponibles para la fecha y sucursal seleccionadas
  const getAvailableTimeSlotsForSelection = () => {
    if (!newAppointment.date || !newAppointment.workCenterId) return [];
    const branchName = getSelectedBranchName();
    return getAvailableTimeSlots(newAppointment.date, branchName);
  };

  // Verificar si una fecha está disponible
  const isDateAvailable = (dateString: string): boolean => {
    if (isDayBlocked(dateString)) return false;
    if (!newAppointment.workCenterId) return true; // Si no hay sucursal seleccionada, mostrar todas
    const branchName = getSelectedBranchName();
    return !isDaySaturated(dateString, branchName);
  };

  // Obtener el estado visual de un día
  const getDateStatus = (dateString: string): { disabled: boolean; className: string; message: string } => {
    if (isDayBlocked(dateString)) {
      return {
        disabled: true,
        className: 'bg-red-100 text-red-800',
        message: 'Día bloqueado - No disponible',
      };
    }
    if (newAppointment.workCenterId) {
      const branchName = getSelectedBranchName();
      if (isDaySaturated(dateString, branchName)) {
        return {
          disabled: true,
          className: 'bg-orange-100 text-orange-800',
          message: 'Día saturado - Sin horarios disponibles',
        };
      }
    }
    return {
      disabled: false,
      className: '',
      message: '',
    };
  };

  const handleScheduleAppointment = async () => {
    if (!newAppointment.serviceId || !newAppointment.workCenterId || !newAppointment.date || !newAppointment.time) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    // Validar que la fecha no esté bloqueada
    if (isDayBlocked(newAppointment.date)) {
      toast.error('Este día no está disponible para citas');
      return;
    }

    // Validar que el horario esté disponible
    const branchName = getSelectedBranchName();
    const availableSlots = getAvailableTimeSlots(newAppointment.date, branchName);
    if (!availableSlots.includes(newAppointment.time)) {
      toast.error('Este horario ya no está disponible');
      return;
    }

    const service = services.find((s) => s.id === newAppointment.serviceId);
    const workCenter = workCenters.find((w) => w.id === newAppointment.workCenterId);

    const appointment: Appointment = {
      id: (appointments.length + 1).toString(),
      patientId: user?.id || '4',
      patientName: user?.name || 'Juan Pérez',
      serviceId: newAppointment.serviceId,
      serviceName: service?.name || '',
      workCenterId: newAppointment.workCenterId,
      workCenterName: workCenter?.name || '',
      date: newAppointment.date,
      time: newAppointment.time,
      status: 'scheduled',
    };

    setAppointments([...appointments, appointment]);
    setNewAppointment({ serviceId: '', workCenterId: '', date: '', time: '' });
    setIsDialogOpen(false);
    toast.success('Cita agendada exitosamente');
    
    // Enviar confirmaciones por correo y WhatsApp
    await sendAppointmentConfirmations({
      patientName: user?.name || 'Juan Pérez',
      patientEmail: user?.email || 'paciente@example.com',
      patientPhone: '4611234567', // En producción, esto vendría de los datos del usuario
      serviceName: service?.name || '',
      date: newAppointment.date,
      time: newAppointment.time,
      workCenterName: workCenter?.name || '',
      workCenterAddress: workCenter?.address || '',
    });
  };

  const handleCancelAppointment = (id: string) => {
    setAppointments(appointments.map((apt) =>
      apt.id === id ? { ...apt, status: 'cancelled' as const } : apt
    ));
    toast.success('Cita cancelada');
  };

  const upcomingAppointments = appointments.filter(
    (apt) => apt.status !== 'cancelled' && new Date(apt.date) >= new Date()
  );
  const pastAppointments = appointments.filter(
    (apt) => apt.status === 'completed' || new Date(apt.date) < new Date()
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl text-sky-600">Bienvenido, {user?.name}</h2>
          <p className="text-gray-600">Gestiona tus citas y consulta tu historial</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-sky-500 hover:bg-sky-600">
              <Plus className="mr-2" size={20} />
              Agendar Cita
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-sky-600">Agendar Nueva Cita</DialogTitle>
              <DialogDescription>
                Selecciona el servicio, sucursal, fecha y hora
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Sucursal</Label>
                <Select
                  value={newAppointment.workCenterId}
                  onValueChange={(value) => {
                    setNewAppointment({ ...newAppointment, workCenterId: value, serviceId: '', time: '' });
                  }}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder="Seleccionar sucursal" />
                  </SelectTrigger>
                  <SelectContent>
                    {workCenters.map((center) => (
                      <SelectItem key={center.id} value={center.id}>
                        {center.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Servicio</Label>
                <Select
                  value={newAppointment.serviceId}
                  onValueChange={(value) =>
                    setNewAppointment({ ...newAppointment, serviceId: value })
                  }
                  disabled={!newAppointment.workCenterId}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder={!newAppointment.workCenterId ? "Primero selecciona una sucursal" : "Seleccionar servicio"} />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableServices().map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        {service.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Fecha</Label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-sky-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                  value={newAppointment.date}
                  onChange={(e) =>
                    setNewAppointment({ ...newAppointment, date: e.target.value, time: '' })
                  }
                  min={new Date().toISOString().split('T')[0]}
                  disabled={!newAppointment.workCenterId}
                />
                {newAppointment.date && isDayBlocked(newAppointment.date) && (
                  <div className="flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="text-red-600" size={16} />
                    <p className="text-sm text-red-700">
                      Este día está bloqueado y no está disponible para citas
                    </p>
                  </div>
                )}
                {newAppointment.date && !isDayBlocked(newAppointment.date) && newAppointment.workCenterId && isDaySaturated(newAppointment.date, getSelectedBranchName()) && (
                  <div className="flex items-center gap-2 p-2 bg-orange-50 border border-orange-200 rounded-md">
                    <AlertCircle className="text-orange-600" size={16} />
                    <p className="text-sm text-orange-700">
                      Este día está saturado - No hay horarios disponibles
                    </p>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Hora</Label>
                <Select
                  value={newAppointment.time}
                  onValueChange={(value) =>
                    setNewAppointment({ ...newAppointment, time: value })
                  }
                  disabled={!newAppointment.date || !newAppointment.workCenterId}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder={
                      !newAppointment.date 
                        ? "Primero selecciona una fecha" 
                        : getAvailableTimeSlotsForSelection().length === 0
                        ? "No hay horarios disponibles"
                        : "Seleccionar hora"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableTimeSlotsForSelection().map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {newAppointment.date && newAppointment.workCenterId && getAvailableTimeSlotsForSelection().length > 0 && (
                  <p className="text-xs text-gray-600">
                    {getAvailableTimeSlotsForSelection().length} horarios disponibles
                  </p>
                )}
              </div>

              <Button
                onClick={handleScheduleAppointment}
                className="w-full bg-sky-500 hover:bg-sky-600"
              >
                Confirmar Cita
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="upcoming">Próximas Citas</TabsTrigger>
          <TabsTrigger value="history">Historial</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingAppointments.length === 0 ? (
            <Card className="border-sky-200">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="text-sky-300 mb-4" size={64} />
                <p className="text-gray-600">No tienes citas próximas</p>
                <Button
                  onClick={() => setIsDialogOpen(true)}
                  className="mt-4 bg-sky-500 hover:bg-sky-600"
                >
                  Agendar Cita
                </Button>
              </CardContent>
            </Card>
          ) : (
            upcomingAppointments.map((appointment) => (
              <Card key={appointment.id} className="border-sky-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-sky-600">{appointment.serviceName}</CardTitle>
                      <CardDescription className="mt-2">
                        {appointment.doctorName && `Con ${appointment.doctorName}`}
                      </CardDescription>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm ${
                      appointment.status === 'confirmed'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {appointment.status === 'confirmed' ? 'Confirmada' : 'Programada'}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Calendar className="text-sky-500" size={16} />
                      <span>{new Date(appointment.date).toLocaleDateString('es-MX', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Clock className="text-sky-500" size={16} />
                      <span>{appointment.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <MapPin className="text-sky-500" size={16} />
                      <span>{appointment.workCenterName}</span>
                    </div>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCancelAppointment(appointment.id)}
                      className="border-red-300 text-red-600 hover:bg-red-50"
                    >
                      <X className="mr-2" size={16} />
                      Cancelar Cita
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {pastAppointments.length === 0 ? (
            <Card className="border-sky-200">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="text-sky-300 mb-4" size={64} />
                <p className="text-gray-600">No tienes historial de citas</p>
              </CardContent>
            </Card>
          ) : (
            pastAppointments.map((appointment) => (
              <Card key={appointment.id} className="border-sky-200 opacity-75">
                <CardHeader>
                  <CardTitle className="text-sky-600">{appointment.serviceName}</CardTitle>
                  <CardDescription>
                    {appointment.doctorName && `Con ${appointment.doctorName}`}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Calendar className="text-sky-500" size={16} />
                      <span>{new Date(appointment.date).toLocaleDateString('es-MX')}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <MapPin className="text-sky-500" size={16} />
                      <span>{appointment.workCenterName}</span>
                    </div>
                    <div className={`inline-block px-3 py-1 rounded-full text-sm ${
                      appointment.status === 'completed'
                        ? 'bg-gray-100 text-gray-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {appointment.status === 'completed' ? 'Completada' : 'Cancelada'}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}