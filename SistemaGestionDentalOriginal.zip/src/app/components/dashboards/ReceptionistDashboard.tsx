import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Calendar, Search, CheckCircle, XCircle, Clock, User, DollarSign, Edit, Plus, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { appointments as initialAppointments, workCenters, patients, services, type Appointment } from '../../data/mockData';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { useAvailability } from '../../context/AvailabilityContext';
import { sendAppointmentConfirmations } from '../../utils/appointmentNotifications';
import { NewAppointmentDialog } from '../NewAppointmentDialog';

export function ReceptionistDashboard() {
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedWorkCenter, setSelectedWorkCenter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<typeof patients[0] | null>(null);
  const [isPatientDialogOpen, setIsPatientDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [paymentData, setPaymentData] = useState({
    servicePrice: 0,
    amountPaid: 0,
    paymentType: 'complete' as 'complete' | 'installment',
    numberOfPayments: 1,
    currentPayment: 1,
  });

  const filteredAppointments = appointments.filter((apt) => {
    const matchesDate = apt.date === selectedDate;
    const matchesWorkCenter = selectedWorkCenter === 'all' || apt.workCenterId === selectedWorkCenter;
    return matchesDate && matchesWorkCenter;
  });

  const handleConfirmAppointment = async (id: string) => {
    const appointment = appointments.find((apt) => apt.id === id);
    if (!appointment) return;
    
    setAppointments(
      appointments.map((apt) =>
        apt.id === id ? { ...apt, status: 'confirmed' as const } : apt
      )
    );
    toast.success('Cita confirmada');
    
    // Encontrar paciente y sucursal para enviar confirmaciones
    const patient = patients.find((p) => p.id === appointment.patientId);
    const workCenter = workCenters.find((w) => w.id === appointment.workCenterId);
    
    if (patient && workCenter) {
      await sendAppointmentConfirmations({
        patientName: patient.name,
        patientEmail: patient.email,
        patientPhone: patient.phone,
        serviceName: appointment.serviceName,
        date: appointment.date,
        time: appointment.time,
        workCenterName: workCenter.name,
        workCenterAddress: workCenter.address,
      });
    }
  };

  const handleCancelAppointment = (id: string) => {
    setAppointments(
      appointments.map((apt) =>
        apt.id === id ? { ...apt, status: 'cancelled' as const } : apt
      )
    );
    toast.success('Cita cancelada');
  };

  const searchResults = patients.filter((patient) =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone.includes(searchTerm)
  );

  const handleViewPatient = (patient: typeof patients[0]) => {
    setSelectedPatient(patient);
    setIsPatientDialogOpen(true);
  };

  const handleOpenPaymentDialog = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    setPaymentData({
      servicePrice: appointment.servicePrice || 0,
      amountPaid: appointment.amountPaid || 0,
      paymentType: appointment.paymentType || 'complete',
      numberOfPayments: appointment.numberOfPayments || 1,
      currentPayment: appointment.currentPayment || 1,
    });
    setIsPaymentDialogOpen(true);
  };

  const handlePaymentChange = (key: keyof typeof paymentData, value: any) => {
    setPaymentData({
      ...paymentData,
      [key]: value,
    });
  };

  const handleSavePayment = () => {
    if (selectedAppointment) {
      const updatedAppointments = appointments.map((apt) =>
        apt.id === selectedAppointment.id
          ? {
              ...apt,
              servicePrice: paymentData.servicePrice,
              amountPaid: paymentData.amountPaid,
              paymentType: paymentData.paymentType,
              numberOfPayments: paymentData.numberOfPayments,
              currentPayment: paymentData.currentPayment,
            }
          : apt
      );
      setAppointments(updatedAppointments);
      toast.success('Información de pago actualizada');
      setIsPaymentDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl text-sky-600">Panel de Recepción</h2>
        <p className="text-gray-600">Gestión de citas y atención a pacientes</p>
      </div>

      {/* Filters */}
      <Card className="border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-600">Filtros de Citas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Fecha</Label>
              <input
                type="date"
                className="w-full px-3 py-2 border border-sky-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Sucursal</Label>
              <Select value={selectedWorkCenter} onValueChange={setSelectedWorkCenter}>
                <SelectTrigger className="border-sky-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las sucursales</SelectItem>
                  {workCenters.map((center) => (
                    <SelectItem key={center.id} value={center.id}>
                      {center.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Appointments Table */}
      <Card className="border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-600">
            Citas del Día ({filteredAppointments.length})
          </CardTitle>
          <CardDescription>
            {new Date(selectedDate).toLocaleDateString('es-MX', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredAppointments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Calendar className="text-sky-300 mb-4" size={64} />
              <p className="text-gray-600">No hay citas para esta fecha</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Hora</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Servicio</TableHead>
                    <TableHead>Doctor</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAppointments.map((appointment) => (
                    <TableRow key={appointment.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="text-sky-500" size={16} />
                          {appointment.time}
                        </div>
                      </TableCell>
                      <TableCell>{appointment.patientName}</TableCell>
                      <TableCell>{appointment.serviceName}</TableCell>
                      <TableCell>{appointment.doctorName || 'Sin asignar'}</TableCell>
                      <TableCell>
                        <div
                          className={`inline-block px-2 py-1 rounded-full text-xs ${
                            appointment.status === 'confirmed'
                              ? 'bg-green-100 text-green-700'
                              : appointment.status === 'cancelled'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {appointment.status === 'confirmed'
                            ? 'Confirmada'
                            : appointment.status === 'cancelled'
                            ? 'Cancelada'
                            : 'Programada'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {appointment.status === 'scheduled' && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => handleConfirmAppointment(appointment.id)}
                                className="bg-green-500 hover:bg-green-600"
                              >
                                <CheckCircle size={16} />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleCancelAppointment(appointment.id)}
                                className="border-red-300 text-red-600 hover:bg-red-50"
                              >
                                <XCircle size={16} />
                              </Button>
                            </>
                          )}
                          {appointment.status === 'confirmed' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOpenPaymentDialog(appointment)}
                              className="border-sky-300 text-sky-600 hover:bg-sky-50"
                            >
                              <DollarSign size={16} />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Patient Search */}
      <Card className="border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-600">Búsqueda de Pacientes</CardTitle>
          <CardDescription>Buscar por nombre o teléfono</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <Input
                placeholder="Buscar paciente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-sky-200 focus:border-sky-500"
              />
            </div>

            {searchTerm && (
              <div className="space-y-2">
                {searchResults.length === 0 ? (
                  <p className="text-gray-600 text-center py-4">No se encontraron pacientes</p>
                ) : (
                  searchResults.map((patient) => (
                    <Card key={patient.id} className="border-sky-100">
                      <CardContent className="flex items-center justify-between p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                            <User className="text-sky-600" size={20} />
                          </div>
                          <div>
                            <p className="text-gray-900">{patient.name}</p>
                            <p className="text-sm text-gray-600">{patient.phone}</p>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewPatient(patient)}
                          className="border-sky-300 text-sky-600 hover:bg-sky-50"
                        >
                          Ver Detalles
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Patient Details Dialog */}
      <Dialog open={isPatientDialogOpen} onOpenChange={setIsPatientDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-sky-600">Información del Paciente</DialogTitle>
          </DialogHeader>
          {selectedPatient && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-600">Nombre</Label>
                  <p className="text-gray-900">{selectedPatient.name}</p>
                </div>
                <div>
                  <Label className="text-gray-600">Email</Label>
                  <p className="text-gray-900">{selectedPatient.email}</p>
                </div>
                <div>
                  <Label className="text-gray-600">Teléfono</Label>
                  <p className="text-gray-900">{selectedPatient.phone}</p>
                </div>
                <div>
                  <Label className="text-gray-600">Edad / Sexo</Label>
                  <p className="text-gray-900">{selectedPatient.age} años / {selectedPatient.sex}</p>
                </div>
                <div className="md:col-span-2">
                  <Label className="text-gray-600">Dirección</Label>
                  <p className="text-gray-900">
                    {selectedPatient.address}, {selectedPatient.colony}, {selectedPatient.delegation}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-600">Ocupación</Label>
                  <p className="text-gray-900">{selectedPatient.occupation}</p>
                </div>
                <div>
                  <Label className="text-gray-600">Tipo de Paciente</Label>
                  <p className="text-gray-900">{selectedPatient.patientType}</p>
                </div>
                {selectedPatient.tutor && (
                  <div>
                    <Label className="text-gray-600">Tutor</Label>
                    <p className="text-gray-900">{selectedPatient.tutor}</p>
                  </div>
                )}
                <div>
                  <Label className="text-gray-600">Fecha de Registro</Label>
                  <p className="text-gray-900">
                    {new Date(selectedPatient.registrationDate).toLocaleDateString('es-MX')}
                  </p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-sky-600">Información de Pago</DialogTitle>
            <DialogDescription>
              Registra el precio del servicio y el pago realizado
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-6">
              {/* Patient and Service Info */}
              <div className="grid md:grid-cols-2 gap-4 p-4 bg-sky-50 rounded-lg">
                <div>
                  <Label className="text-gray-600 text-sm">Paciente</Label>
                  <p className="text-gray-900">{selectedAppointment.patientName}</p>
                </div>
                <div>
                  <Label className="text-gray-600 text-sm">Servicio</Label>
                  <p className="text-gray-900">{selectedAppointment.serviceName}</p>
                </div>
                <div>
                  <Label className="text-gray-600 text-sm">Fecha</Label>
                  <p className="text-gray-900">
                    {new Date(selectedAppointment.date).toLocaleDateString('es-MX')}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-600 text-sm">Hora</Label>
                  <p className="text-gray-900">{selectedAppointment.time}</p>
                </div>
              </div>

              {/* Payment Fields */}
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="servicePrice">Precio del Servicio *</Label>
                    <Input
                      id="servicePrice"
                      type="number"
                      step="0.01"
                      value={paymentData.servicePrice}
                      onChange={(e) => handlePaymentChange('servicePrice', parseFloat(e.target.value) || 0)}
                      className="border-sky-200 focus:border-sky-500"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amountPaid">Monto Pagado / A Cta *</Label>
                    <Input
                      id="amountPaid"
                      type="number"
                      step="0.01"
                      value={paymentData.amountPaid}
                      onChange={(e) => handlePaymentChange('amountPaid', parseFloat(e.target.value) || 0)}
                      className="border-sky-200 focus:border-sky-500"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Tipo de Pago</Label>
                  <RadioGroup
                    value={paymentData.paymentType}
                    onValueChange={(value) => handlePaymentChange('paymentType', value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="complete" id="complete" />
                      <Label htmlFor="complete" className="cursor-pointer">Pago Completo</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="installment" id="installment" />
                      <Label htmlFor="installment" className="cursor-pointer">Pago en Cuotas (A Cta)</Label>
                    </div>
                  </RadioGroup>
                </div>

                {paymentData.paymentType === 'installment' && (
                  <div className="grid md:grid-cols-2 gap-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="space-y-2">
                      <Label htmlFor="numberOfPayments">Número Total de Pagos</Label>
                      <Input
                        id="numberOfPayments"
                        type="number"
                        min="2"
                        value={paymentData.numberOfPayments}
                        onChange={(e) => handlePaymentChange('numberOfPayments', parseInt(e.target.value) || 1)}
                        className="border-yellow-300 focus:border-yellow-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="currentPayment">Pago Actual (Número)</Label>
                      <Input
                        id="currentPayment"
                        type="number"
                        min="1"
                        max={paymentData.numberOfPayments}
                        value={paymentData.currentPayment}
                        onChange={(e) => handlePaymentChange('currentPayment', parseInt(e.target.value) || 1)}
                        className="border-yellow-300 focus:border-yellow-500"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-sm text-gray-600">
                        <strong>Pendiente:</strong> ${(paymentData.servicePrice - paymentData.amountPaid).toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-600">
                        Pagando cuota {paymentData.currentPayment} de {paymentData.numberOfPayments}
                      </p>
                    </div>
                  </div>
                )}

                {paymentData.paymentType === 'complete' && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-700">
                      ✓ Pago completo de ${paymentData.servicePrice.toFixed(2)}
                    </p>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsPaymentDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleSavePayment}
                  className="bg-sky-500 hover:bg-sky-600"
                >
                  Guardar Información de Pago
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* New Appointment Dialog */}
      <div className="fixed bottom-6 right-6">
        <NewAppointmentDialog
          onAppointmentCreated={(appointment) => setAppointments([...appointments, appointment])}
          existingAppointments={appointments}
        />
      </div>
    </div>
  );
}