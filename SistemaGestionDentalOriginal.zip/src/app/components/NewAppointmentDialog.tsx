import { useState } from 'react';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, AlertCircle, User, Search, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { services, workCenters, type Appointment } from '../data/mockData';
import { useAvailability } from '../context/AvailabilityContext';
import { usePatients } from '../context/PatientContext';
import { sendAppointmentConfirmations } from '../utils/appointmentNotifications';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface NewAppointmentDialogProps {
  onAppointmentCreated: (appointment: Appointment) => void;
  existingAppointments: Appointment[];
}

interface NewPatientData {
  name: string;
  email: string;
  phone: string;
  age: string;
  sex: 'Masculino' | 'Femenino' | '';
}

export function NewAppointmentDialog({ onAppointmentCreated, existingAppointments }: NewAppointmentDialogProps) {
  const { getAvailableTimeSlots, isDayBlocked, isDaySaturated } = useAvailability();
  const { patients } = usePatients();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [patientType, setPatientType] = useState<'existing' | 'new'>('existing');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState('');
  
  const [newPatientData, setNewPatientData] = useState<NewPatientData>({
    name: '',
    email: '',
    phone: '',
    age: '',
    sex: '',
  });
  
  const [newAppointment, setNewAppointment] = useState({
    serviceId: '',
    workCenterId: '',
    date: '',
    time: '',
  });

  const getSelectedBranchName = () => {
    const workCenter = workCenters.find((w) => w.id === newAppointment.workCenterId);
    return workCenter?.name || '';
  };

  const getAvailableServices = () => {
    if (!newAppointment.workCenterId) return [];
    const branchName = getSelectedBranchName();
    return services.filter((s) => s.branch === branchName);
  };

  const getAvailableTimeSlotsForSelection = () => {
    if (!newAppointment.date || !newAppointment.workCenterId) return [];
    const branchName = getSelectedBranchName();
    return getAvailableTimeSlots(newAppointment.date, branchName);
  };

  const searchResults = patients.filter((patient) =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone.includes(searchTerm) ||
    patient.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedPatient = patients.find((p) => p.id === selectedPatientId);

  const validateNewPatient = () => {
    if (!newPatientData.name.trim()) {
      toast.error('El nombre del paciente es obligatorio');
      return false;
    }
    if (!newPatientData.phone.trim()) {
      toast.error('El teléfono del paciente es obligatorio');
      return false;
    }
    if (!newPatientData.email.trim()) {
      toast.error('El email del paciente es obligatorio');
      return false;
    }
    if (!newPatientData.email.includes('@')) {
      toast.error('El email no es válido');
      return false;
    }
    return true;
  };

  const handleScheduleAppointment = async () => {
    // Validar según el tipo de paciente
    if (patientType === 'existing' && !selectedPatientId) {
      toast.error('Por favor selecciona un paciente');
      return;
    }

    if (patientType === 'new' && !validateNewPatient()) {
      return;
    }
    
    if (!newAppointment.serviceId || !newAppointment.workCenterId || !newAppointment.date || !newAppointment.time) {
      toast.error('Por favor completa todos los campos de la cita');
      return;
    }

    // Validar que la fecha no esté bloqueada
    if (isDayBlocked(newAppointment.date)) {
      toast.error('Este día no está disponible para citas');
      return;
    }

    // Validar que el horario esté disponible
    const branchName = getSelectedBranchName();
    const availableSlots = getAvailableTimeSlots(newAppointment.date, branchName);
    if (!availableSlots.includes(newAppointment.time)) {
      toast.error('Este horario ya no está disponible');
      return;
    }

    const service = services.find((s) => s.id === newAppointment.serviceId);
    const workCenter = workCenters.find((w) => w.id === newAppointment.workCenterId);

    let patientName = '';
    let patientEmail = '';
    let patientPhone = '';
    let patientId = '';

    if (patientType === 'existing') {
      const patient = patients.find((p) => p.id === selectedPatientId);
      if (!patient) {
        toast.error('Paciente no encontrado');
        return;
      }
      patientName = patient.name;
      patientEmail = patient.email;
      patientPhone = patient.phone;
      patientId = patient.id;
    } else {
      // Paciente nuevo
      patientName = newPatientData.name;
      patientEmail = newPatientData.email;
      patientPhone = newPatientData.phone;
      patientId = `new-${Date.now()}`; // ID temporal para paciente nuevo
      
      toast.success('Paciente nuevo registrado', {
        description: `Se ha registrado a ${patientName} en el sistema`,
      });
    }

    const appointment: Appointment = {
      id: (existingAppointments.length + 1).toString(),
      patientId: patientId,
      patientName: patientName,
      serviceId: newAppointment.serviceId,
      serviceName: service?.name || '',
      workCenterId: newAppointment.workCenterId,
      workCenterName: workCenter?.name || '',
      date: newAppointment.date,
      time: newAppointment.time,
      status: 'scheduled',
    };

    onAppointmentCreated(appointment);
    toast.success('Cita agendada exitosamente');
    
    // Enviar confirmaciones por correo y WhatsApp
    await sendAppointmentConfirmations({
      patientName: patientName,
      patientEmail: patientEmail,
      patientPhone: patientPhone,
      serviceName: service?.name || '',
      date: newAppointment.date,
      time: newAppointment.time,
      workCenterName: workCenter?.name || '',
      workCenterAddress: workCenter?.address || '',
    });

    // Reset form
    setNewAppointment({ serviceId: '', workCenterId: '', date: '', time: '' });
    setSelectedPatientId('');
    setSearchTerm('');
    setNewPatientData({ name: '', email: '', phone: '', age: '', sex: '' });
    setPatientType('existing');
    setIsDialogOpen(false);
  };

  const isFormValid = () => {
    const appointmentValid = newAppointment.serviceId && newAppointment.workCenterId && newAppointment.date && newAppointment.time;
    
    if (patientType === 'existing') {
      return appointmentValid && selectedPatientId;
    } else {
      return appointmentValid && newPatientData.name && newPatientData.email && newPatientData.phone;
    }
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button className="bg-sky-500 hover:bg-sky-600">
          <Plus className="mr-2" size={20} />
          Agendar Cita para Paciente
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-sky-600">Agendar Nueva Cita</DialogTitle>
          <DialogDescription>
            Registra un paciente nuevo o busca uno existente. Se enviará confirmación por correo y WhatsApp.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Tabs para seleccionar tipo de paciente */}
          <Tabs value={patientType} onValueChange={(value) => setPatientType(value as 'existing' | 'new')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="existing" className="flex items-center gap-2">
                <Search size={16} />
                Paciente Existente
              </TabsTrigger>
              <TabsTrigger value="new" className="flex items-center gap-2">
                <UserPlus size={16} />
                Paciente Nuevo
              </TabsTrigger>
            </TabsList>

            {/* Paciente Existente */}
            <TabsContent value="existing" className="space-y-4 mt-4">
              <div className="space-y-3">
                <Label>Buscar Paciente *</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <Input
                    placeholder="Buscar por nombre, teléfono o email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 border-sky-200 focus:border-sky-500"
                  />
                </div>
                
                {searchTerm && (
                  <div className="max-h-48 overflow-y-auto space-y-2 border border-sky-200 rounded-md p-2">
                    {searchResults.length === 0 ? (
                      <div className="text-center py-4">
                        <p className="text-gray-600 mb-2">No se encontraron pacientes</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setPatientType('new');
                            setSearchTerm('');
                          }}
                          className="border-sky-300 text-sky-600"
                        >
                          <UserPlus className="mr-2" size={16} />
                          Registrar como Paciente Nuevo
                        </Button>
                      </div>
                    ) : (
                      searchResults.map((patient) => (
                        <Card
                          key={patient.id}
                          className={`cursor-pointer transition-all ${
                            selectedPatientId === patient.id
                              ? 'border-sky-500 bg-sky-50'
                              : 'border-sky-100 hover:border-sky-300'
                          }`}
                          onClick={() => {
                            setSelectedPatientId(patient.id);
                            setSearchTerm('');
                          }}
                        >
                          <CardContent className="flex items-center gap-3 p-3">
                            <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                              <User className="text-sky-600" size={20} />
                            </div>
                            <div className="flex-1">
                              <p className="text-gray-900 font-medium">{patient.name}</p>
                              <p className="text-sm text-gray-600">{patient.phone} • {patient.email}</p>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                )}

                {selectedPatient && !searchTerm && (
                  <Card className="border-sky-500 bg-sky-50">
                    <CardContent className="flex items-center justify-between p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-sky-200 rounded-full flex items-center justify-center">
                          <User className="text-sky-700" size={20} />
                        </div>
                        <div>
                          <p className="text-gray-900 font-medium">{selectedPatient.name}</p>
                          <p className="text-sm text-gray-600">{selectedPatient.phone} • {selectedPatient.email}</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedPatientId('')}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        Cambiar
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Paciente Nuevo */}
            <TabsContent value="new" className="space-y-4 mt-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <UserPlus className="text-green-600 mt-0.5" size={20} />
                  <div>
                    <p className="text-sm font-medium text-green-800">Registro de Paciente Nuevo</p>
                    <p className="text-xs text-green-700 mt-1">
                      Complete los datos del paciente. Después de agendar la cita, se enviará confirmación automática.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new-patient-name">Nombre Completo *</Label>
                  <Input
                    id="new-patient-name"
                    placeholder="Ej: Juan Pérez García"
                    value={newPatientData.name}
                    onChange={(e) => setNewPatientData({ ...newPatientData, name: e.target.value })}
                    className="border-sky-200 focus:border-sky-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-patient-phone">Teléfono *</Label>
                  <Input
                    id="new-patient-phone"
                    placeholder="Ej: 4611234567"
                    value={newPatientData.phone}
                    onChange={(e) => setNewPatientData({ ...newPatientData, phone: e.target.value })}
                    className="border-sky-200 focus:border-sky-500"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="new-patient-email">Correo Electrónico *</Label>
                  <Input
                    id="new-patient-email"
                    type="email"
                    placeholder="Ej: juan.perez@example.com"
                    value={newPatientData.email}
                    onChange={(e) => setNewPatientData({ ...newPatientData, email: e.target.value })}
                    className="border-sky-200 focus:border-sky-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-patient-age">Edad (Opcional)</Label>
                  <Input
                    id="new-patient-age"
                    type="number"
                    placeholder="Ej: 30"
                    value={newPatientData.age}
                    onChange={(e) => setNewPatientData({ ...newPatientData, age: e.target.value })}
                    className="border-sky-200 focus:border-sky-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-patient-sex">Sexo (Opcional)</Label>
                  <Select
                    value={newPatientData.sex}
                    onValueChange={(value) => setNewPatientData({ ...newPatientData, sex: value as 'Masculino' | 'Femenino' })}
                  >
                    <SelectTrigger className="border-sky-200">
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Masculino">Masculino</SelectItem>
                      <SelectItem value="Femenino">Femenino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Detalles de la Cita (común para ambos) */}
          <div className="border-t pt-4">
            <h3 className="text-sm font-medium text-gray-700 mb-4">Detalles de la Cita</h3>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Sucursal *</Label>
                <Select
                  value={newAppointment.workCenterId}
                  onValueChange={(value) => {
                    setNewAppointment({ ...newAppointment, workCenterId: value, serviceId: '', time: '' });
                  }}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder="Seleccionar sucursal" />
                  </SelectTrigger>
                  <SelectContent>
                    {workCenters.map((center) => (
                      <SelectItem key={center.id} value={center.id}>
                        {center.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Servicio *</Label>
                <Select
                  value={newAppointment.serviceId}
                  onValueChange={(value) =>
                    setNewAppointment({ ...newAppointment, serviceId: value })
                  }
                  disabled={!newAppointment.workCenterId}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder={!newAppointment.workCenterId ? "Primero selecciona una sucursal" : "Seleccionar servicio"} />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableServices().map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        {service.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Fecha *</Label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-sky-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                  value={newAppointment.date}
                  onChange={(e) =>
                    setNewAppointment({ ...newAppointment, date: e.target.value, time: '' })
                  }
                  min={new Date().toISOString().split('T')[0]}
                  disabled={!newAppointment.workCenterId}
                />
                {newAppointment.date && isDayBlocked(newAppointment.date) && (
                  <div className="flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="text-red-600" size={16} />
                    <p className="text-sm text-red-700">
                      Este día está bloqueado y no está disponible para citas
                    </p>
                  </div>
                )}
                {newAppointment.date && !isDayBlocked(newAppointment.date) && newAppointment.workCenterId && isDaySaturated(newAppointment.date, getSelectedBranchName()) && (
                  <div className="flex items-center gap-2 p-2 bg-orange-50 border border-orange-200 rounded-md">
                    <AlertCircle className="text-orange-600" size={16} />
                    <p className="text-sm text-orange-700">
                      Este día está saturado - No hay horarios disponibles
                    </p>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Hora *</Label>
                <Select
                  value={newAppointment.time}
                  onValueChange={(value) =>
                    setNewAppointment({ ...newAppointment, time: value })
                  }
                  disabled={!newAppointment.date || !newAppointment.workCenterId}
                >
                  <SelectTrigger className="border-sky-200">
                    <SelectValue placeholder={
                      !newAppointment.date 
                        ? "Primero selecciona una fecha" 
                        : getAvailableTimeSlotsForSelection().length === 0
                        ? "No hay horarios disponibles"
                        : "Seleccionar hora"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableTimeSlotsForSelection().map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {newAppointment.date && newAppointment.workCenterId && getAvailableTimeSlotsForSelection().length > 0 && (
                  <p className="text-xs text-gray-600">
                    {getAvailableTimeSlotsForSelection().length} horarios disponibles
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                setIsDialogOpen(false);
                setNewAppointment({ serviceId: '', workCenterId: '', date: '', time: '' });
                setSelectedPatientId('');
                setSearchTerm('');
                setNewPatientData({ name: '', email: '', phone: '', age: '', sex: '' });
                setPatientType('existing');
              }}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleScheduleAppointment}
              className="bg-sky-500 hover:bg-sky-600"
              disabled={!isFormValid()}
            >
              {patientType === 'new' ? 'Registrar Paciente y Agendar Cita' : 'Confirmar y Enviar Notificaciones'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}