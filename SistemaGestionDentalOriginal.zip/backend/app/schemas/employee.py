"""
Schemas de Empleado
"""
from typing import Optional, List
from datetime import date, datetime
from decimal import Decimal
from pydantic import BaseModel, Field, ConfigDict


class EmployeeBase(BaseModel):
    """Schema base de Empleado"""
    numero_empleado: str = Field(..., max_length=50, description="Número de empleado único")
    fecha_ingreso: date = Field(..., description="Fecha de ingreso a la empresa")
    cedula_profesional: Optional[str] = Field(None, max_length=50, description="Cédula profesional")
    salario: Optional[Decimal] = Field(None, ge=0, description="Salario mensual")
    notas: Optional[str] = None


class EmployeeCreate(EmployeeBase):
    """Schema para crear Empleado"""
    usuario_id: int = Field(..., description="ID del usuario asociado")
    especialidad_ids: List[int] = Field(default=[], description="IDs de especialidades del empleado")


class EmployeeUpdate(BaseModel):
    """Schema para actualizar Empleado"""
    numero_empleado: Optional[str] = Field(None, max_length=50)
    fecha_ingreso: Optional[date] = None
    cedula_profesional: Optional[str] = Field(None, max_length=50)
    salario: Optional[Decimal] = Field(None, ge=0)
    notas: Optional[str] = None
    especialidad_ids: Optional[List[int]] = Field(None, description="IDs de especialidades")


class EmployeeResponse(EmployeeBase):
    """Schema de respuesta de Empleado"""
    model_config = ConfigDict(from_attributes=True)

    id: int
    usuario_id: int
    fecha_creacion: datetime
    fecha_actualizacion: datetime

    # Información del usuario asociado
    usuario_nombre: Optional[str] = None
    usuario_email: Optional[str] = None

    # Especialidades
    especialidades: List[str] = Field(default=[], description="Nombres de especialidades")

    @classmethod
    def from_orm_with_relations(cls, employee):
        """Constructor personalizado para incluir relaciones"""
        return cls(
            id=employee.id,
            usuario_id=employee.usuario_id,
            numero_empleado=employee.numero_empleado,
            fecha_ingreso=employee.fecha_ingreso,
            cedula_profesional=employee.cedula_profesional,
            salario=employee.salario,
            notas=employee.notas,
            fecha_creacion=employee.fecha_creacion,
            fecha_actualizacion=employee.fecha_actualizacion,
            usuario_nombre=f"{employee.usuario.nombre} {employee.usuario.apellido_paterno}" if employee.usuario else None,
            usuario_email=employee.usuario.email if employee.usuario else None,
            especialidades=[esp.nombre for esp in employee.especialidades] if employee.especialidades else []
        )
