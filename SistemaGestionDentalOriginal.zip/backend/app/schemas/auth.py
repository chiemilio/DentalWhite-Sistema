"""
Schemas de Autenticación
"""
from pydantic import BaseModel, EmailStr, Field


class LoginRequest(BaseModel):
    """Request para login"""
    email: EmailStr = Field(..., description="Email del usuario")
    password: str = Field(..., min_length=8, description="Contraseña del usuario")


class LoginResponse(BaseModel):
    """Response de login exitoso"""
    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field(default="bearer", description="Tipo de token")
    user_id: int = Field(..., description="ID del usuario")
    email: str = Field(..., description="Email del usuario")
    nombre_completo: str = Field(..., description="Nombre completo del usuario")
    rol: str = Field(..., description="Nombre del rol")


class TokenPayload(BaseModel):
    """Payload del JWT token"""
    sub: int = Field(..., description="User ID")
    exp: int = Field(..., description="Expiration timestamp")
    iat: int = Field(..., description="Issued at timestamp")
    iss: str = Field(..., description="Issuer")
    aud: str = Field(..., description="Audience")
