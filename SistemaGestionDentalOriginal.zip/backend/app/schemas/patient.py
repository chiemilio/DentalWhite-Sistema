"""
Schemas de Paciente
"""
from typing import Optional
from datetime import date, datetime
from pydantic import BaseModel, EmailStr, Field, ConfigDict


class PatientBase(BaseModel):
    """Schema base de Paciente"""
    tipo_paciente_id: int = Field(..., description="ID del tipo de paciente")
    sucursal_id: int = Field(..., description="ID de la sucursal")
    fecha_nacimiento: date = Field(..., description="Fecha de nacimiento")
    genero: str = Field(..., pattern="^(M|F|Otro)$", description="Género: M, F, Otro")
    tipo_sangre: Optional[str] = Field(None, max_length=10, description="Tipo de sangre")

    # Dirección
    calle: Optional[str] = Field(None, max_length=200)
    numero_exterior: Optional[str] = Field(None, max_length=20)
    numero_interior: Optional[str] = Field(None, max_length=20)
    colonia: Optional[str] = Field(None, max_length=100)
    ciudad: Optional[str] = Field(None, max_length=100)
    estado: Optional[str] = Field(None, max_length=100)
    codigo_postal: Optional[str] = Field(None, max_length=10)

    # Contacto de emergencia
    nombre_emergencia: Optional[str] = Field(None, max_length=200)
    telefono_emergencia: Optional[str] = Field(None, max_length=20)
    relacion_emergencia: Optional[str] = Field(None, max_length=50)

    # Tutor (para menores)
    requiere_tutor: bool = Field(default=False)
    nombre_tutor: Optional[str] = Field(None, max_length=200)
    telefono_tutor: Optional[str] = Field(None, max_length=20)
    parentesco_tutor: Optional[str] = Field(None, max_length=50)

    # Medio de contacto
    medio_contacto_id: Optional[int] = Field(None, description="Cómo conoció la clínica")
    notas: Optional[str] = None


class PatientCreate(PatientBase):
    """Schema para crear Paciente"""
    usuario_id: int = Field(..., description="ID del usuario asociado")


class PatientUpdate(BaseModel):
    """Schema para actualizar Paciente"""
    tipo_paciente_id: Optional[int] = None
    sucursal_id: Optional[int] = None
    fecha_nacimiento: Optional[date] = None
    genero: Optional[str] = Field(None, pattern="^(M|F|Otro)$")
    tipo_sangre: Optional[str] = Field(None, max_length=10)

    # Dirección
    calle: Optional[str] = Field(None, max_length=200)
    numero_exterior: Optional[str] = Field(None, max_length=20)
    numero_interior: Optional[str] = Field(None, max_length=20)
    colonia: Optional[str] = Field(None, max_length=100)
    ciudad: Optional[str] = Field(None, max_length=100)
    estado: Optional[str] = Field(None, max_length=100)
    codigo_postal: Optional[str] = Field(None, max_length=10)

    # Contacto de emergencia
    nombre_emergencia: Optional[str] = Field(None, max_length=200)
    telefono_emergencia: Optional[str] = Field(None, max_length=20)
    relacion_emergencia: Optional[str] = Field(None, max_length=50)

    # Tutor
    requiere_tutor: Optional[bool] = None
    nombre_tutor: Optional[str] = Field(None, max_length=200)
    telefono_tutor: Optional[str] = Field(None, max_length=20)
    parentesco_tutor: Optional[str] = Field(None, max_length=50)

    medio_contacto_id: Optional[int] = None
    notas: Optional[str] = None


class PatientResponse(PatientBase):
    """Schema de respuesta de Paciente"""
    model_config = ConfigDict(from_attributes=True)

    id: int
    usuario_id: int
    numero_expediente: str
    fecha_registro: datetime
    fecha_actualizacion: datetime

    # Información del usuario asociado
    usuario_nombre: Optional[str] = None
    usuario_email: Optional[str] = None

    @classmethod
    def from_orm_with_relations(cls, patient):
        """Constructor personalizado para incluir datos del usuario"""
        return cls(
            id=patient.id,
            usuario_id=patient.usuario_id,
            tipo_paciente_id=patient.tipo_paciente_id,
            sucursal_id=patient.sucursal_id,
            numero_expediente=patient.numero_expediente,
            fecha_nacimiento=patient.fecha_nacimiento,
            genero=patient.genero,
            tipo_sangre=patient.tipo_sangre,
            calle=patient.calle,
            numero_exterior=patient.numero_exterior,
            numero_interior=patient.numero_interior,
            colonia=patient.colonia,
            ciudad=patient.ciudad,
            estado=patient.estado,
            codigo_postal=patient.codigo_postal,
            nombre_emergencia=patient.nombre_emergencia,
            telefono_emergencia=patient.telefono_emergencia,
            relacion_emergencia=patient.relacion_emergencia,
            requiere_tutor=patient.requiere_tutor,
            nombre_tutor=patient.nombre_tutor,
            telefono_tutor=patient.telefono_tutor,
            parentesco_tutor=patient.parentesco_tutor,
            medio_contacto_id=patient.medio_contacto_id,
            notas=patient.notas,
            fecha_registro=patient.fecha_registro,
            fecha_actualizacion=patient.fecha_actualizacion,
            usuario_nombre=f"{patient.usuario.nombre} {patient.usuario.apellido_paterno}" if patient.usuario else None,
            usuario_email=patient.usuario.email if patient.usuario else None
        )
