"""
Endpoints de Pacientes
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.patient import Patient
from app.schemas.patient import PatientCreate, PatientUpdate, PatientResponse
from app.api.deps import get_current_user, require_role

router = APIRouter()


@router.get("/", response_model=List[PatientResponse])
def list_patients(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Lista todos los pacientes
    """
    patients = db.query(Patient).offset(skip).limit(limit).all()
    return [PatientResponse.from_orm_with_relations(patient) for patient in patients]


@router.get("/{patient_id}", response_model=PatientResponse)
def get_patient(
    patient_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Obtiene un paciente por ID
    """
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paciente no encontrado"
        )
    return PatientResponse.from_orm_with_relations(patient)


@router.post("/", response_model=PatientResponse, status_code=status.HTTP_201_CREATED)
def create_patient(
    patient_data: PatientCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin", "Recepcionista"))
):
    """
    Crea un nuevo paciente
    """
    # Verificar que el usuario exista
    user = db.query(User).filter(User.id == patient_data.usuario_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuario no encontrado"
        )

    # Verificar que el usuario no tenga ya un perfil de paciente
    existing_patient = db.query(Patient).filter(Patient.usuario_id == patient_data.usuario_id).first()
    if existing_patient:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El usuario ya tiene un perfil de paciente"
        )

    # Generar número de expediente (último + 1)
    last_patient = db.query(Patient).order_by(Patient.id.desc()).first()
    next_number = 1 if not last_patient else int(last_patient.numero_expediente.split("-")[1]) + 1
    numero_expediente = f"PAC-{next_number:06d}"

    # Crear paciente
    db_patient = Patient(
        usuario_id=patient_data.usuario_id,
        tipo_paciente_id=patient_data.tipo_paciente_id,
        sucursal_id=patient_data.sucursal_id,
        numero_expediente=numero_expediente,
        fecha_nacimiento=patient_data.fecha_nacimiento,
        genero=patient_data.genero,
        tipo_sangre=patient_data.tipo_sangre,
        calle=patient_data.calle,
        numero_exterior=patient_data.numero_exterior,
        numero_interior=patient_data.numero_interior,
        colonia=patient_data.colonia,
        ciudad=patient_data.ciudad,
        estado=patient_data.estado,
        codigo_postal=patient_data.codigo_postal,
        nombre_emergencia=patient_data.nombre_emergencia,
        telefono_emergencia=patient_data.telefono_emergencia,
        relacion_emergencia=patient_data.relacion_emergencia,
        requiere_tutor=patient_data.requiere_tutor,
        nombre_tutor=patient_data.nombre_tutor,
        telefono_tutor=patient_data.telefono_tutor,
        parentesco_tutor=patient_data.parentesco_tutor,
        medio_contacto_id=patient_data.medio_contacto_id,
        notas=patient_data.notas
    )

    db.add(db_patient)
    db.commit()
    db.refresh(db_patient)

    return PatientResponse.from_orm_with_relations(db_patient)


@router.put("/{patient_id}", response_model=PatientResponse)
def update_patient(
    patient_id: int,
    patient_update: PatientUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin", "Recepcionista"))
):
    """
    Actualiza un paciente
    """
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paciente no encontrado"
        )

    # Actualizar campos proporcionados
    update_data = patient_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(patient, field, value)

    db.commit()
    db.refresh(patient)

    return PatientResponse.from_orm_with_relations(patient)


@router.delete("/{patient_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_patient(
    patient_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin"))
):
    """
    Elimina un paciente (Solo Admin/SuperAdmin)
    """
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paciente no encontrado"
        )

    db.delete(patient)
    db.commit()

    return None
