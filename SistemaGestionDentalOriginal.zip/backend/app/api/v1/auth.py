"""
Endpoints de Autenticación
"""
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.core.security import verify_password, create_access_token, get_password_hash
from app.schemas.auth import LoginRequest, LoginResponse
from app.schemas.user import UserCreate, UserResponse
from app.api.deps import get_current_user
from app.config import settings

router = APIRouter()


@router.post("/login", response_model=LoginResponse)
def login(login_data: LoginRequest, db: Session = Depends(get_db)):
    """
    Login de usuario - Retorna JWT token
    """
    # Buscar usuario por email
    user = db.query(User).filter(User.email == login_data.email).first()

    # Verificar que exista y la contraseña sea correcta
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o contraseña incorrectos",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Verificar que el usuario esté activo
    if not user.activo:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Usuario inactivo"
        )

    # Crear access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id)},
        expires_delta=access_token_expires
    )

    # Retornar token y datos del usuario
    return LoginResponse(
        access_token=access_token,
        token_type="bearer",
        user_id=user.id,
        email=user.email,
        nombre_completo=f"{user.nombre} {user.apellido_paterno}",
        rol=user.rol.nombre if user.rol else "Sin rol"
    )


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    Registro de nuevo usuario
    """
    # Verificar que el email no esté en uso
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado"
        )

    # Verificar CURP único si se proporciona
    if user_data.curp:
        existing_curp = db.query(User).filter(User.curp == user_data.curp).first()
        if existing_curp:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El CURP ya está registrado"
            )

    # Verificar RFC único si se proporciona
    if user_data.rfc:
        existing_rfc = db.query(User).filter(User.rfc == user_data.rfc).first()
        if existing_rfc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El RFC ya está registrado"
            )

    # Crear usuario
    db_user = User(
        email=user_data.email,
        password_hash=get_password_hash(user_data.password),
        nombre=user_data.nombre,
        apellido_paterno=user_data.apellido_paterno,
        apellido_materno=user_data.apellido_materno,
        telefono=user_data.telefono,
        curp=user_data.curp,
        rfc=user_data.rfc,
        nacionalidad_id=user_data.nacionalidad_id,
        rol_id=user_data.rol_id,
        activo=user_data.activo
    )

    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    return UserResponse.from_orm_with_relations(db_user)


@router.get("/me", response_model=UserResponse)
def get_current_user_info(current_user: User = Depends(get_current_user)):
    """
    Obtiene información del usuario autenticado actual
    """
    return UserResponse.from_orm_with_relations(current_user)
