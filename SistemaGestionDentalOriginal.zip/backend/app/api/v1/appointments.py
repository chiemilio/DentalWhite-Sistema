"""
Endpoints de Citas
"""
from typing import List
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.appointment import Appointment
from app.schemas.appointment import AppointmentCreate, AppointmentUpdate, AppointmentResponse
from app.api.deps import get_current_user, require_role

router = APIRouter()


@router.get("/", response_model=List[AppointmentResponse])
def list_appointments(
    skip: int = 0,
    limit: int = 100,
    fecha_inicio: datetime | None = Query(None, description="Filtrar desde fecha"),
    fecha_fin: datetime | None = Query(None, description="Filtrar hasta fecha"),
    paciente_id: int | None = Query(None, description="Filtrar por paciente"),
    empleado_id: int | None = Query(None, description="Filtrar por empleado"),
    estado_id: int | None = Query(None, description="Filtrar por estado"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Lista todas las citas con filtros opcionales
    """
    query = db.query(Appointment)

    # Aplicar filtros
    if fecha_inicio:
        query = query.filter(Appointment.fecha_hora >= fecha_inicio)
    if fecha_fin:
        query = query.filter(Appointment.fecha_hora <= fecha_fin)
    if paciente_id:
        query = query.filter(Appointment.paciente_id == paciente_id)
    if empleado_id:
        query = query.filter(Appointment.empleado_id == empleado_id)
    if estado_id:
        query = query.filter(Appointment.estado_cita_id == estado_id)

    appointments = query.order_by(Appointment.fecha_hora.desc()).offset(skip).limit(limit).all()
    return [AppointmentResponse.from_orm_with_relations(appointment) for appointment in appointments]


@router.get("/{appointment_id}", response_model=AppointmentResponse)
def get_appointment(
    appointment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Obtiene una cita por ID
    """
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cita no encontrada"
        )
    return AppointmentResponse.from_orm_with_relations(appointment)


@router.post("/", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED)
def create_appointment(
    appointment_data: AppointmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin", "Recepcionista", "Doctor"))
):
    """
    Crea una nueva cita
    """
    # TODO: Verificar disponibilidad del empleado en el horario solicitado
    # TODO: Verificar conflictos con otras citas o bloqueos de agenda

    db_appointment = Appointment(
        paciente_id=appointment_data.paciente_id,
        empleado_id=appointment_data.empleado_id,
        servicio_id=appointment_data.servicio_id,
        sucursal_id=appointment_data.sucursal_id,
        estado_cita_id=appointment_data.estado_cita_id,
        fecha_hora=appointment_data.fecha_hora,
        duracion_minutos=appointment_data.duracion_minutos,
        motivo=appointment_data.motivo,
        notas=appointment_data.notas
    )

    db.add(db_appointment)
    db.commit()
    db.refresh(db_appointment)

    return AppointmentResponse.from_orm_with_relations(db_appointment)


@router.put("/{appointment_id}", response_model=AppointmentResponse)
def update_appointment(
    appointment_id: int,
    appointment_update: AppointmentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin", "Recepcionista", "Doctor"))
):
    """
    Actualiza una cita
    """
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cita no encontrada"
        )

    # Actualizar campos proporcionados
    update_data = appointment_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(appointment, field, value)

    db.commit()
    db.refresh(appointment)

    return AppointmentResponse.from_orm_with_relations(appointment)


@router.delete("/{appointment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_appointment(
    appointment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin", "Recepcionista"))
):
    """
    Cancela/Elimina una cita
    """
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cita no encontrada"
        )

    # Podríamos cambiar el estado a "Cancelada" en lugar de eliminar
    # Por ahora, eliminamos
    db.delete(appointment)
    db.commit()

    return None
