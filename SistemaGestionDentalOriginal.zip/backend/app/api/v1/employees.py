"""
Endpoints de Empleados
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.employee import Employee
from app.models.catalogos import Especialidad
from app.schemas.employee import EmployeeCreate, EmployeeUpdate, EmployeeResponse
from app.api.deps import get_current_user, require_role

router = APIRouter()


@router.get("/", response_model=List[EmployeeResponse])
def list_employees(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Lista todos los empleados
    """
    employees = db.query(Employee).offset(skip).limit(limit).all()
    return [EmployeeResponse.from_orm_with_relations(employee) for employee in employees]


@router.get("/{employee_id}", response_model=EmployeeResponse)
def get_employee(
    employee_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Obtiene un empleado por ID
    """
    employee = db.query(Employee).filter(Employee.id == employee_id).first()
    if not employee:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Empleado no encontrado"
        )
    return EmployeeResponse.from_orm_with_relations(employee)


@router.post("/", response_model=EmployeeResponse, status_code=status.HTTP_201_CREATED)
def create_employee(
    employee_data: EmployeeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin"))
):
    """
    Crea un nuevo empleado (Solo Admin/SuperAdmin)
    """
    # Verificar que el usuario exista
    user = db.query(User).filter(User.id == employee_data.usuario_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuario no encontrado"
        )

    # Verificar que el usuario no tenga ya un perfil de empleado
    existing_employee = db.query(Employee).filter(Employee.usuario_id == employee_data.usuario_id).first()
    if existing_employee:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El usuario ya tiene un perfil de empleado"
        )

    # Verificar número de empleado único
    existing_numero = db.query(Employee).filter(Employee.numero_empleado == employee_data.numero_empleado).first()
    if existing_numero:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El número de empleado ya está en uso"
        )

    # Crear empleado
    db_employee = Employee(
        usuario_id=employee_data.usuario_id,
        numero_empleado=employee_data.numero_empleado,
        fecha_ingreso=employee_data.fecha_ingreso,
        cedula_profesional=employee_data.cedula_profesional,
        salario=employee_data.salario,
        notas=employee_data.notas
    )

    # Asignar especialidades si se proporcionan
    if employee_data.especialidad_ids:
        especialidades = db.query(Especialidad).filter(
            Especialidad.id.in_(employee_data.especialidad_ids)
        ).all()
        db_employee.especialidades = especialidades

    db.add(db_employee)
    db.commit()
    db.refresh(db_employee)

    return EmployeeResponse.from_orm_with_relations(db_employee)


@router.put("/{employee_id}", response_model=EmployeeResponse)
def update_employee(
    employee_id: int,
    employee_update: EmployeeUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin"))
):
    """
    Actualiza un empleado (Solo Admin/SuperAdmin)
    """
    employee = db.query(Employee).filter(Employee.id == employee_id).first()
    if not employee:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Empleado no encontrado"
        )

    # Actualizar campos proporcionados
    update_data = employee_update.model_dump(exclude_unset=True, exclude={"especialidad_ids"})

    # Verificar número de empleado único si se está actualizando
    if "numero_empleado" in update_data and update_data["numero_empleado"] != employee.numero_empleado:
        existing_numero = db.query(Employee).filter(
            Employee.numero_empleado == update_data["numero_empleado"]
        ).first()
        if existing_numero:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El número de empleado ya está en uso"
            )

    # Aplicar actualizaciones
    for field, value in update_data.items():
        setattr(employee, field, value)

    # Actualizar especialidades si se proporcionan
    if employee_update.especialidad_ids is not None:
        especialidades = db.query(Especialidad).filter(
            Especialidad.id.in_(employee_update.especialidad_ids)
        ).all()
        employee.especialidades = especialidades

    db.commit()
    db.refresh(employee)

    return EmployeeResponse.from_orm_with_relations(employee)


@router.delete("/{employee_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_employee(
    employee_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("Admin", "SuperAdmin"))
):
    """
    Elimina un empleado (Solo Admin/SuperAdmin)
    """
    employee = db.query(Employee).filter(Employee.id == employee_id).first()
    if not employee:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Empleado no encontrado"
        )

    db.delete(employee)
    db.commit()

    return None
