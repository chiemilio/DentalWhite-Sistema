"""
Endpoints de Catálogos
"""
from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel, ConfigDict

from app.database import get_db
from app.models.catalogos import (
    TipoPaciente, Sucursal, Nacionalidad, Rol, Especialidad,
    Servicio, MedioContacto, EstadoCita, TipoAntecedente
)

router = APIRouter()


# Schemas genéricos para catálogos
class CatalogoBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    nombre: str
    activo: bool


class RolResponse(CatalogoBase):
    permisos: dict = {}


class ServicioResponse(CatalogoBase):
    descripcion: str | None = None
    duracion_minutos: int = 30
    precio_base: float | None = None


class SucursalResponse(CatalogoBase):
    direccion: str | None = None
    telefono: str | None = None
    email: str | None = None


@router.get("/tipos-paciente", response_model=List[CatalogoBase])
def get_tipos_paciente(db: Session = Depends(get_db)):
    """Obtiene todos los tipos de paciente"""
    return db.query(TipoPaciente).filter(TipoPaciente.activo == True).all()


@router.get("/sucursales", response_model=List[SucursalResponse])
def get_sucursales(db: Session = Depends(get_db)):
    """Obtiene todas las sucursales"""
    return db.query(Sucursal).filter(Sucursal.activo == True).all()


@router.get("/nacionalidades", response_model=List[CatalogoBase])
def get_nacionalidades(db: Session = Depends(get_db)):
    """Obtiene todas las nacionalidades"""
    return db.query(Nacionalidad).filter(Nacionalidad.activo == True).all()


@router.get("/roles", response_model=List[RolResponse])
def get_roles(db: Session = Depends(get_db)):
    """Obtiene todos los roles"""
    return db.query(Rol).filter(Rol.activo == True).all()


@router.get("/especialidades", response_model=List[CatalogoBase])
def get_especialidades(db: Session = Depends(get_db)):
    """Obtiene todas las especialidades"""
    return db.query(Especialidad).filter(Especialidad.activo == True).all()


@router.get("/servicios", response_model=List[ServicioResponse])
def get_servicios(db: Session = Depends(get_db)):
    """Obtiene todos los servicios"""
    return db.query(Servicio).filter(Servicio.activo == True).all()


@router.get("/medios-contacto", response_model=List[CatalogoBase])
def get_medios_contacto(db: Session = Depends(get_db)):
    """Obtiene todos los medios de contacto"""
    return db.query(MedioContacto).filter(MedioContacto.activo == True).all()


@router.get("/estados-cita", response_model=List[CatalogoBase])
def get_estados_cita(db: Session = Depends(get_db)):
    """Obtiene todos los estados de cita"""
    return db.query(EstadoCita).filter(EstadoCita.activo == True).all()


@router.get("/tipos-antecedente", response_model=List[CatalogoBase])
def get_tipos_antecedente(db: Session = Depends(get_db)):
    """Obtiene todos los tipos de antecedente"""
    return db.query(TipoAntecedente).filter(TipoAntecedente.activo == True).all()
