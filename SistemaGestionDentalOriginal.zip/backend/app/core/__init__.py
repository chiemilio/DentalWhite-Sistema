"""
Core functionality
"""
